#!/bin/sh

exec "$@"
